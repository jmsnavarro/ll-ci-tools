# CircleCI

[![CircleCI](https://circleci.com/gh/automate6500/circleci-demo.svg?style=svg)](https://circleci.com/gh/automate6500/circleci-demo)

Files for CircleCI.
