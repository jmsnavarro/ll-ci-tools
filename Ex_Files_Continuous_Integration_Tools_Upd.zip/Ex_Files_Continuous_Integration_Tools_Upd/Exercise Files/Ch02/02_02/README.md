# CodeShip

[![Codeship Status for automate6500/codeship-demo](https://app.codeship.com/projects/b7d19870-09b8-0137-fc98-06b77dea8d40/status?branch=master)](https://app.codeship.com/projects/326141)

Files for CodeShip
