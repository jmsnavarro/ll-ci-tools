# GCP Cloud Build
Files for Google Cloud Platform's Cloud Build
